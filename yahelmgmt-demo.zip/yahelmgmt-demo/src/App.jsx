import React from 'react';
import './App.css';

const talents = [
  {
    name: "אורי נוביק",
    instagram: "https://www.instagram.com/ori_novik?igsh=OTllc3htbHEweHo5",
    tiktok: "https://www.tiktok.com/@ori_novik?_t=ZS-8tR97IY47aq&_r=1",
  },
  {
    name: "בר גניש ברבוריתה",
    instagram: "https://www.instagram.com/bar_genish/",
    tiktok: "https://www.tiktok.com/@bar_genish",
  },
  {
    name: "מישל דדשב",
    instagram: "https://www.instagram.com/mishel_d_?igsh=MTR5OHAyaGU2YW55NQ==",
    tiktok: "https://www.tiktok.com/@mishel_d_?_t=ZS-8tUjBTSZTQA&_r=1",
  },
  {
    name: "סשה רחמינוב",
    instagram: "https://www.instagram.com/sasharachminov/",
    tiktok: "https://www.tiktok.com/@sashaspammm1?_t=8r6zbASaLho&_r=1",
  },
  {
    name: "צחי צאושו",
    instagram: "https://www.instagram.com/zahieatingisrael/",
    tiktok: "https://www.tiktok.com/@zahieatingisrael",
  },
  {
    name: "עדן קקון",
    instagram: "https://www.instagram.com/edenkakon_chef?igsh=Y3RzNDgwNWJnaHBl",
  },
  {
    name: "שני אלון",
    instagram: "https://www.instagram.com/shani.alon?igsh=MXVrN2FpN3d2cTQyZQ==",
  },
  {
    name: "אנגל ברנס",
    instagram: "https://www.instagram.com/angelbaranes?igsh=M3h1eHFpbGw1MXVl",
    tiktok: "https://www.tiktok.com/@angelbaranes",
  },
  {
    name: "אלירן חנניה",
    instagram: "https://www.instagram.com/eliranhannia/",
    tiktok: "https://www.tiktok.com/@eliranhannia?lang=en",
  },
  {
    name: "ליהי לוי",
    instagram: "https://www.instagram.com/lihi._levi/",
    tiktok: "https://www.tiktok.com/@lihilevii?lang=en",
  },
  {
    name: "רומי צורני",
    instagram: "https://www.instagram.com/romitsurani_?igsh=MXM3NzdkZGwwdjE2dg==",
    tiktok: "https://www.tiktok.com/@rommitsurani_",
  },
  {
    name: "ליזה פירסוב",
    instagram: "https://www.instagram.com/liza_firsov/",
    tiktok: "https://www.tiktok.com/@lizafirsov",
  },
];

function App() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(to bottom, #F9F6F3, #F3D1D6, #D8A7B1)',
      padding: '2rem',
      fontFamily: 'sans-serif',
      color: '#3E3E3E'
    }}>
      <header style={{ textAlign: 'center', padding: '2rem' }}>
        <h1 style={{ fontSize: '2.5rem', color: '#935F6C' }}>YAHELMGMT</h1>
        <p>ניהול טאלנטים ויוצרי תוכן</p>
      </header>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '1.5rem',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        {talents.map((talent, index) => (
          <div key={index} style={{
            backgroundColor: '#fff',
            border: '1px solid #EADDDD',
            borderRadius: '1rem',
            padding: '1.5rem',
            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
            textAlign: 'center',
            transition: 'transform 0.2s',
          }}>
            <h2 style={{ color: '#935F6C', fontWeight: 'bold' }}>{talent.name}</h2>
            <div style={{ marginTop: '1rem' }}>
              {talent.instagram && (
                <a href={talent.instagram} target="_blank" rel="noreferrer" style={{
                  display: 'inline-block',
                  margin: '0.5rem',
                  padding: '0.5rem 1rem',
                  border: '1px solid #D8A7B1',
                  color: '#935F6C',
                  borderRadius: '6px',
                  textDecoration: 'none',
                  backgroundColor: '#F9F6F3'
                }}>אינסטגרם</a>
              )}
              {talent.tiktok && (
                <a href={talent.tiktok} target="_blank" rel="noreferrer" style={{
                  display: 'inline-block',
                  margin: '0.5rem',
                  padding: '0.5rem 1rem',
                  border: '1px solid #D8A7B1',
                  color: '#935F6C',
                  borderRadius: '6px',
                  textDecoration: 'none',
                  backgroundColor: '#F9F6F3'
                }}>טיקטוק</a>
              )}
            </div>
          </div>
        ))}
      </div>

      <footer style={{ textAlign: 'center', marginTop: '4rem', fontSize: '0.9rem' }}>
        © 2025 Yahelmgmt. כל הזכויות שמורות.
      </footer>
    </div>
  );
}

export default App;
